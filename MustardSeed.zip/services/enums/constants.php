<?php
class Constants
{
    const ACCOUNT_VERIFIED = '1';
}
