<?php

    class ResetPasswordResponse {
        // Columns
        public $code;
        public $desc;
        public $verificationCode;

        public function __construct(){
            
        }
    }
?>