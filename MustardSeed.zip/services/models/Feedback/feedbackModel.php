<?php
class FeedbackModel
{

    // Columns
    public $id;
    public $rating;
    public $review;
    public $bookingId;

    // Db connection
    public function __construct()
    {
    }
}
