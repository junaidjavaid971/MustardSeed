﻿<?php

    class Response {
        // Columns
        public $code;
        public $desc;
        public $data;

        public function __construct(){
            
        }
    }

?>